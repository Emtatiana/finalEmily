export const environment = {
  firebase: {
    projectId: 'licencias-web',
    appId: '1:66494900289:web:26e0673db295bd53b07ec0',
    databaseURL: 'https://licencias-web-default-rtdb.firebaseio.com',
    storageBucket: 'licencias-web.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyCGdyB18MbVRRWeLa6AYYduWjjjd9Ik_vQ',
    authDomain: 'licencias-web.firebaseapp.com',
    messagingSenderId: '66494900289',
  },
};