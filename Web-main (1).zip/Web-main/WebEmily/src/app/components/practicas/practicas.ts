export interface practica {
    id?: string
    actividad?: string
    horas?: number;
    observaciones?: string
  }