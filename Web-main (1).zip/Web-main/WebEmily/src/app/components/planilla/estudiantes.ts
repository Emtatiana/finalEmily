export interface estudiante {
   id?: string,
   nombre?: string, 
   nivel?: string, 
   edad?: string, 
   campus?:string, 
   carrera?:string, 
   correo?:string
  }