export interface ActividadesMedicas {
    id: number;
    fecha: string;
    actividad: string;
    detalle: string;
    estado: string;
    id_usuario: number;
  }