export interface Doctor {
    id: number;
    nombre: number;
    telefono: string;
    correo: string;
    especializacion: string;
    id_usuario: number;
  }